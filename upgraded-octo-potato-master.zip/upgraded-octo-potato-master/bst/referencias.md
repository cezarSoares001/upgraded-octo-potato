
# Componentes para árvores
https://docs.oracle.com/javafx/2/ui_controls/tree-view.htm
http://docs.oracle.com/javase/tutorial/uiswing/components/tree.html
